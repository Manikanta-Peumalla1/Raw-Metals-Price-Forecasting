# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 18:00:09 2024

@author: 
"""

# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error
from math import sqrt
from sklearn.preprocessing import MinMaxScaler
from sqlalchemy import create_engine 


# Connecting to sql by creating sqlachemy engine
engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}".format(user = "root", pw = "SaiNerya0308", db = "company")) # database

user = 'root'
pw = 'SaiNerya0308'
db = 'assignments'


# Read csv file 
df = pd.read_excel(r"C:\Users\swamy\Desktop\Fore casting Project\Raw Material(Minerals  Metals).xlsx")

# dumping data into database 
df.to_sql('metals', con = engine, if_exists = 'replace', chunksize = 1000, index = False)


# loading data from database
sql = 'select * from metals'

metals = pd.read_sql_query(sql, con = engine )

print(metals)


df.describe()
metals = ['FN', 'Aluminium', 'Molybdenum', 'Vanadium', 'Graphite', 'Manganese', 'Fluorite']

# Four  Business moments
for i in metals:
    i_mean = df.loc[df['Metal Name'] == i, 'Price'].mean()
    i_median = df.loc[df['Metal Name'] == i, 'Price'].median()
    i_skew = df.loc[df['Metal Name'] == i, 'Price'].skew()
    i_kurtosis = df.loc[df['Metal Name'] == i, 'Price'].kurtosis()
    print('Mean of ' + i + ':', i_mean)
    print('Median of ' + i + ':', i_median)
    print('Skew of ' + i + ':', i_skew)
    print('Kurtosis of ' + i + ':', i_kurtosis)
    print('------------------')
    
# Handling Missing Values

#df.replace(" ", np.nan, inplace=True)

#Typecasting- Converting the datatype of Month coulmn from string to datetime format

df['Month'] = pd.to_datetime(df['Month'], format = '%b-%y') 

df.sort_values('Month', inplace=True)
df.isnull().sum()
metals = ['FN', 'Aluminium', 'Molybdenum', 'Vanadium', 'Graphite', 'Manganese', 'Fluorite']

for metal in metals:
    metal_data = df[df['Metal_Name'] == metal]
    plt.plot(metal_data['Month'], metal_data['Price'], label = metal)
    plt.xlabel('Month')
    plt.ylabel('Price')
    plt.title('Metal Prices Over Time')
    plt.legend()
    plt.xticks(rotation=45)
    plt.show()
    

for metal in metals:
    metal_df = df[df['Metal Name'] == metal].copy()
    metal_df['Price'] = metal_df['Price'].interpolate(method='linear')
    # Sort by years
    metal_df.sort_values(by='Month', inplace=True)
    # Interpolate missing values based on the 2nd year data
    # metal_df['Price'] = metal_df['Price'].interpolate(method='polynomial',order=2)
    # metal_df = metal_df.interpolate(method='linear')
    # metal_df = metal_df.interpolate(method='spline', order=3)
    print('Interpolated data for', metal)
    print(metal_df)
    print('------------------')
    
###Auto EDA    
import sweetviz
my_report = sweetviz.analyze([metals, "metals"])

my_report.show_html('Report.html')
